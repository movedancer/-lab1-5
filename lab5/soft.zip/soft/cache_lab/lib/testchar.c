int testchar()
{
return *(volatile char *)(SERIAL+1);
}
